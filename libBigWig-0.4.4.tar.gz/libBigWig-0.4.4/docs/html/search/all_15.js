var searchData=
[
  ['zoomhdrs',['zoomHdrs',['../structbigWigHdr__t.html#a0faf3ffe182eb803cd4f98b6a0a8d69c',1,'bigWigHdr_t']]]
];
