var searchData=
[
  ['idx',['idx',['../structbwZoomHdr__t.html#a8bcd89608bfc17b5432d6ca9b2374d7a',1,'bwZoomHdr_t::idx()'],['../structbigWigFile__t.html#a448fd3c9fc0cf6f3a0ffa98b1a6d3199',1,'bigWigFile_t::idx()']]],
  ['idxsize',['idxSize',['../structbwRTree__t.html#a119af9ef30b2923ccb7e4ae8a6d3b501',1,'bwRTree_t']]],
  ['indexoffset',['indexOffset',['../structbwZoomHdr__t.html#a8d7a1c8741ecbecde64f462267f0f116',1,'bwZoomHdr_t::indexOffset()'],['../structbigWigHdr__t.html#a933b1bc6988c30fca67bb392a04b7357',1,'bigWigHdr_t::indexOffset()']]],
  ['intervals',['intervals',['../structbwOverlapIterator__t.html#a5e1e6474d26a3e5900e6b91603e0664a',1,'bwOverlapIterator_t']]],
  ['iscompressed',['isCompressed',['../structURL__t.html#ab1fe842d66e490e6851ec2fe4e5276e6',1,'URL_t']]],
  ['isleaf',['isLeaf',['../structbwRTreeNode__t.html#aa2dac9df29c6b9eaaf4000e70f3e1540',1,'bwRTreeNode_t']]],
  ['iswrite',['isWrite',['../structbigWigFile__t.html#a76e415b9a2933c94927c4e137057bd4a',1,'bigWigFile_t']]]
];
