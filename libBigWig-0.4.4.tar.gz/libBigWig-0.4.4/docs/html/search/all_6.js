var searchData=
[
  ['global_5fdefaultbuffersize',['GLOBAL_DEFAULTBUFFERSIZE',['../bigWigIO_8h.html#a2f4038b5ef0a0e7dc45a20fc0bb83925',1,'io.c']]]
];
