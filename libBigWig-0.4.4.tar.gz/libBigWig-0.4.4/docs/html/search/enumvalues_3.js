var searchData=
[
  ['max',['max',['../bigWig_8h.html#aa3e01d7486887aa111417b688bc1a22ca6eba708e9255d1bb06879b30b47422ff',1,'bigWig.h']]],
  ['mean',['mean',['../bigWig_8h.html#aa3e01d7486887aa111417b688bc1a22ca73aa25ce744f80bc0f1c0e991a509638',1,'bigWig.h']]],
  ['min',['min',['../bigWig_8h.html#aa3e01d7486887aa111417b688bc1a22ca1e491e9b59d4f6891eb2929589487dfc',1,'bigWig.h']]]
];
