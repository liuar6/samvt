var searchData=
[
  ['default_5fblocksize',['DEFAULT_BLOCKSIZE',['../bigWig_8h.html#a46a626f6d8b24b07925d82cde2175864',1,'bigWig.h']]],
  ['default_5fnchildren',['DEFAULT_nCHILDREN',['../bigWig_8h.html#ac0d6303cef22d415a53d150be8f06623',1,'bigWig.h']]]
];
