var searchData=
[
  ['cov',['cov',['../bigWig_8h.html#aa3e01d7486887aa111417b688bc1a22caf866615ac99c2e47027ea68849ef849f',1,'bigWig.h']]],
  ['coverage',['coverage',['../bigWig_8h.html#aa3e01d7486887aa111417b688bc1a22ca02bbe932c03913324065a5318a16e715',1,'bigWig.h']]]
];
