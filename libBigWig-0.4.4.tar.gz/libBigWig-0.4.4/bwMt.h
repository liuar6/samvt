#ifndef BWMT_H
#define BWMT_H

#include "mt.h"
#include "mt_buffer.h"
#include "zlib.h"

typedef struct {
    int not_init;
    struct bigWigFile_t *fp;
    mt_buffer *b;
    int buffer_count;
    mt_queue *q;
    mt_server *s;
    int error;
    pthread_t mt_writer;
    pthread_mutex_t m;
} bigWigMt_t;

typedef struct {
    uint32_t tid;
    uint32_t start;
    uint32_t end;
    Bytef *b;
    Bytef *zb;
    uLongf b_size;
    Bytef *cb;
    uLongf cb_size;
    int ret;
} compressMtArgs;

int addIndexEntry(struct bigWigFile_t *fp, uint32_t tid0, uint32_t tid1, uint32_t start, uint32_t end, uint64_t offset, uint64_t size);
void *compressMt(void * _arg);
void *flushBufferMtWriter(void * _arg);
void *writeZoomLevelsWtDispatcher(void *_arg);
int bwMtInit(struct bigWigFile_t *fp, mt_server *s);

#endif
