#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "bigWig.h"
#include "bwCommon.h"
#include "bwMt.h"

void *compressMt(void * _arg){
    compressMtArgs *arg = _arg;
    arg->ret = compress(arg->cb, &arg->cb_size, arg->b, arg->b_size);
    return arg;
}

void *compress2Mt(void * _arg){
    compressMtArgs *arg = _arg;
    arg->ret = compress(arg->cb, &arg->cb_size, arg->zb, arg->b_size);
    return arg;
}

void *flushBufferMtWriter(void * _arg){
    bigWigMt_t *mt = _arg;
    mt_queue *q = mt->q;
    mt_buffer *b = mt->b;
    bigWigFile_t *fp = mt->fp;
    int error = 0;
    compressMtArgs *arg;
    void *ret;
    while (mt_queue_receive(q, &ret, 0) == 0){
        arg = ret;
        if (arg->ret != Z_OK) {
            error = 1;
            goto error;
        }
        if (fwrite(arg->cb, sizeof(uint8_t), arg->cb_size, fp->URL->x.fp) != arg->cb_size) {
            error = 2;
            goto error;
        }
        if (addIndexEntry(fp, arg->tid, arg->tid, arg->start, arg->end, bwTell(fp) - arg->cb_size, arg->cb_size)) {
            error = 3;
            goto error;
        };
        mt_buffer_put(b, arg);
    }
    return NULL;
error:
    mt->error = error;
    pthread_mutex_unlock(&mt->m);
    mt_buffer_put(mt->b, arg);
    return NULL;
}

void *writeZoomLevelsWtDispatcher(void *_arg){
    bigWigMt_t *mt = _arg;
    bigWigFile_t *fp = mt->fp;
    mt_queue *q = mt->q;
    mt_buffer *b = mt->b;
    for(int i=0; i<fp->hdr->nLevels; i++) {
        if (i && fp->writeBuffer->nNodes[i] == fp->writeBuffer->nNodes[i - 1]) break;
        bwZoomBuffer_t *zb = fp->writeBuffer->firstZoomBuffer[i];
        while (zb) {
            uLongf sz = fp->hdr->bufSize;
            compressMtArgs *arg = mt_buffer_get(b);
            arg->zb = zb->p;
            arg->b_size = zb->l;
            arg->cb_size = sz;
            arg->ret = 0;
            int ret = mt_queue_dispatch(q, compress2Mt, arg, NULL, NULL, 0);
            if (ret != 0) {
                mt->error = 1;
                mt_buffer_put(b, arg);
                return NULL;
            }
            zb = zb->next;
        }
    }
    mt_queue_dispatch_end(q);
    return NULL;
}

int bwMtInit(bigWigFile_t *fp, mt_server *s){ /* no malloc check currently */
    int n_thread = mt_server_n_thread(s);
    bigWigMt_t *mt = malloc(sizeof(*mt));
    mt->fp = fp;
    mt->s = s;
    mt->q = mt_queue_init(s, INT_MAX, INT_MAX, MT_QUEUE_MODE_SERIAL);
    mt->b = mt_buffer_init();
    mt->buffer_count = n_thread *4;
    for (int i = 0; i < mt->buffer_count; ++i){
        compressMtArgs *arg = malloc(sizeof(*arg));
        arg->cb = malloc(fp->writeBuffer->compressPsz);
        arg->b = malloc(fp->hdr->bufSize);
        mt_buffer_put(mt->b, arg);
    }
    mt->error = 0;
    pthread_create(&mt->mt_writer, NULL, flushBufferMtWriter, mt);
    fp->mt = mt;
    return 0;
}

int bwMtDestroy(bigWigFile_t *fp){ /* no malloc check currently */
    bigWigMt_t *mt = fp->mt;
    for (int i = 0; i < mt->buffer_count; ++i){
        compressMtArgs *arg =mt_buffer_get(mt->b);
        free(arg->cb);
        free(arg->b);
        free(arg);
    }
    mt_buffer_destroy(mt->b, NULL);
    free(mt);
    return 0;
}

