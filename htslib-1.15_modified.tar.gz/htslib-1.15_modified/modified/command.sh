mkdir modified
mkdir modified/old
mv Makefile modified/old

rm ./thread_pool.c
cp ../mt/hts/thread_pool.c ./
gawk '{gsub("-lpthread", "-lpthread -lmt", $0); gsub("libhts.", "libhtsm.", $0); gsub("(includedir)/htslib", "(includedir)/htslibm.", $0); print}' modified/old/Makefile  > Makefile
