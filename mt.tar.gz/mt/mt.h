/* The MIT License (MIT)

   Copyright (c) 2023 Anrui Liu <liuar6@gmail.com>

   Permission is hereby granted, free of charge, to any person obtaining
   a copy of this software and associated documentation files (the
   “Software”), to deal in the Software without restriction, including
   without limitation the rights to use, copy, modify, merge, publish,
   distribute, sublicense, and/or sell copies of the Software, and to
   permit persons to whom the Software is furnished to do so, subject to
   the following conditions:

   The above copyright notice and this permission notice shall be
   included in all copies or substantial portions of the Software.

   THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND,
   EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
   MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
   NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
   BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
   ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
   CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   SOFTWARE.
 */

#define MT_VERSION "1.0.0"

#ifndef MT_H
#define MT_H
#include "pthread.h"
#include "stdint.h"

typedef struct mt_thread{
    struct mt_server *s;
    int idx;
    uint32_t status;
    pthread_t tid;
    pthread_cond_t  pending_c;
} mt_thread;

typedef struct mt_server{
    struct mt_queue *q_head;
    struct mt_queue *q_tail;

    int n_thread;
    int n_thread_pending;

    struct mt_thread *t;

    pthread_mutex_t server_m;
} mt_server;


typedef struct mt_queue{
    int mode;
    uint64_t next_serial;
    uint64_t curr_serial;

    int job_capacity;
    int n_job;
    struct mt_job *job_head;
    struct mt_job *job_tail;
    int n_job_unused;
    struct mt_job *job_unused;

    int result_capacity;
    int n_result;
    struct mt_result *result_head;
    struct mt_result *result_tail;
    int n_result_unused;
    struct mt_result *result_unused;

    int n_processing;
    pthread_cond_t job_avail_c;
    int job_avail_wait;
    pthread_cond_t result_avail_c;
    int result_avail_wait;

    pthread_cond_t wait_c;

    uint32_t dispatch_mode;

    int n_thread;
    int ref_count;
    uint32_t flag;
    struct mt_queue *next;
    struct mt_server *s;
} mt_queue;

typedef struct mt_job{
    struct mt_job *next;
    int serial;
    void *( *func)(void *);
    void (*job_cleanup)(void *arg);
    void (*result_cleanup)(void *data);
    void *data;
} mt_job;
typedef struct mt_result{
    struct mt_result *next;
    struct mt_result *prev;
    void (*result_cleanup)(void *data);
    int serial;
    void *data;
} mt_result;

#define MT_THREAD_AVAILABLE 0u
#define MT_THREAD_WORKING 1u
#define MT_THREAD_BANISHED 2u

#define MT_QUEUE_MODE_DEFAULT 0u
#define MT_QUEUE_MODE_IGNORED 1u
#define MT_QUEUE_MODE_SERIAL 2u

#define MT_QUEUE_NO_MORE_USER 1u
#define MT_QUEUE_SHUTDOWN 2u
#define MT_QUEUE_AUTO_DESTROY 4u
#define MT_QUEUE_DISPATCH_END 8u
#define MT_QUEUE_RECEIVE_END 16u

#define MT_QUEUE_DISPATCH_UNBLOCK 1
#define MT_QUEUE_DISPATCH_BLOCK 2
#define MT_QUEUE_DISPATCH_UNBLOCK_ONCE 4

#define MT_FINISH 0
#define MT_FLUSH 1

int mt_queue_dispatch_mode(mt_queue *q, uint32_t flag);
int mt_queue_dispatch_end(mt_queue *q);
int mt_queue_dispatch(mt_queue *q, void *(*func)(void *), void *arg, void (*job_cleanup)(void *), void (*result_cleanup)(void *), int non_block);
int mt_queue_receive(mt_queue *q, void **ret, int non_block);
mt_server *mt_server_init(int n);
int mt_server_destroy(struct mt_server *s);
mt_queue *mt_queue_init(mt_server *s, int job_capacity, int result_capacity, int mode);
int mt_queue_wait(mt_queue *q, int f);
int mt_queue_set_job_capacity(mt_queue *q, int capacity);
int mt_queue_set_result_capacity(mt_queue *q, int capacity);
int mt_queue_reset(mt_queue *q);
int mt_queue_shutdown_locked(mt_queue *q);
int mt_queue_shutdown(mt_queue *q);
int mt_queue_destroy_locked(mt_queue *q);
int mt_queue_auto_destroy(mt_queue *q);
int mt_queue_destroy(mt_queue *q);
int mt_queue_ref_incr(mt_queue *q);
int mt_queue_ref_decr(mt_queue *q);
int mt_queue_attach(mt_queue *q, mt_server *s);
int mt_queue_detach_locked(mt_queue *q);
int mt_queue_detach(mt_queue *q);

int mt_server_n_thread(mt_server *s);

#endif