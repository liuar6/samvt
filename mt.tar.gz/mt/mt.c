/* The MIT License (MIT)

   Copyright (c) 2023 Anrui Liu <liuar6@gmail.com>

   Permission is hereby granted, free of charge, to any person obtaining
   a copy of this software and associated documentation files (the
   “Software”), to deal in the Software without restriction, including
   without limitation the rights to use, copy, modify, merge, publish,
   distribute, sublicense, and/or sell copies of the Software, and to
   permit persons to whom the Software is furnished to do so, subject to
   the following conditions:

   The above copyright notice and this permission notice shall be
   included in all copies or substantial portions of the Software.

   THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND,
   EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
   MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
   NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
   BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
   ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
   CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   SOFTWARE.
 */

#include <stdio.h>
#include <zconf.h>
#include <pthread.h>
#include <stdlib.h>
#include <limits.h>

#include "mt.h"

static inline int mt_queue_check_wait(mt_queue *q);

static int call_worker(mt_queue *q){
    int n_needed_thread;
    int n_called_thread;
    if (!q) return 0;
    mt_server *s = q->s;
    if (s->n_thread_pending == 0) return 0;
    s = q->s;

    n_needed_thread = q->result_capacity - q->n_result - q->n_processing;
    if (n_needed_thread > q->n_job) n_needed_thread = q->n_job;
    if (n_needed_thread > s->n_thread_pending) n_needed_thread = s->n_thread_pending;
    if (n_needed_thread == 0) return 0;

    n_called_thread = 0;
    for (int i = 0; i < s->n_thread; ++i){
        if (s->t[i].status == MT_THREAD_AVAILABLE) {
            pthread_cond_signal(&s->t[i].pending_c);
            n_called_thread++;
        }
        if (n_called_thread > n_needed_thread) break;
    }
    return 0;
}

static mt_queue *check_queue(mt_thread *t){
    mt_queue *q = t->s->q_head;
    while (q != NULL){
        if (!(q->flag & MT_QUEUE_SHUTDOWN) && q->job_head && (q->result_capacity > q->n_result + q->n_processing)) break;
        q = q->next;
    }
    return q;
}


static void *mt_worker(void *arg){
    mt_thread *t = (mt_thread *)arg;
    mt_server *s = t->s;
    mt_queue *q;
    mt_job *j;
    mt_result *r;
    mt_result *last;
    void *ret_val;

    pthread_mutex_lock(&s->server_m);
    if (t->status == MT_THREAD_BANISHED) {
        pthread_mutex_unlock(&s->server_m);
        return NULL;
    }
    while (1){
        while (!(q = check_queue(t))){
            t->status = MT_THREAD_AVAILABLE;
            s->n_thread_pending++;
            pthread_cond_wait(&t->pending_c, &s->server_m);
            s->n_thread_pending--;
            if (t->status == MT_THREAD_BANISHED) {
                pthread_mutex_unlock(&s->server_m);
                return NULL;
            }
        }
        t->status = MT_THREAD_WORKING;
        q->n_thread++;
        while (!(q->flag & MT_QUEUE_SHUTDOWN) && q->job_head && (q->result_capacity > q->n_processing + q->n_result)){
            j = q->job_head;
            q->job_head = j->next;
            if (!q->job_head) q->job_tail = NULL;
            q->n_job--;
            /* although n_job is reduced here, n_processing is going to be added, so there is no need to wake dispatchers */

            if (q->mode != MT_QUEUE_MODE_IGNORED){
                if (q->result_unused) {
                    r = q->result_unused;
                    q->result_unused = r->next;
                    q->n_result_unused--;
                } else r = malloc(sizeof(*r));
                if (!r) { /* simply insert the job back and break*/
                    if (!q->job_head) q->job_head = q->job_tail = j;
                    else {
                        j->next = q->job_head;
                        q->job_head = j;
                    }
                    usleep(10000);
                    break;
                }
            } else r = NULL;

            q->n_processing++;

            pthread_mutex_unlock(&s->server_m);
            ret_val = j->func(j->data);
            pthread_mutex_lock(&s->server_m);

            q->n_processing--;
            if (q->job_avail_wait) pthread_cond_broadcast(&q->job_avail_c);

            if (r){
                r->prev = NULL;
                r->next = NULL;
                r->data = ret_val;
                r->serial = j->serial;
                r->result_cleanup = j->result_cleanup;
                if (q->mode == MT_QUEUE_MODE_SERIAL){
                    if (!q->result_head){
                        q->result_head = r;
                        q->result_tail = r;
                    } else if (r->serial > q->result_head->serial){
                        r->next = q->result_head;
                        r->next->prev = r;
                        q->result_head = r;
                    } else{
                        last = q->result_head;
                        while (last->next && r->serial < last->next->serial) last = last->next;
                        if (!last->next){
                            last->next = r;
                            r->prev = last;
                            q->result_tail = r;
                        } else{
                            r->next = last->next;
                            r->next->prev = r;
                            r->prev = last;
                            last->next = r;
                        }
                    }
                    q->n_result++;
                    if (q->result_avail_wait && r->serial == q->next_serial) pthread_cond_broadcast(&q->result_avail_c);
                } else if (q->mode == MT_QUEUE_MODE_DEFAULT){
                    if (!q->result_head){
                        q->result_head = r;
                        q->result_tail = r;
                    } else {
                        r->next = q->result_head;
                        r->next->prev = r;
                        q->result_head = r;
                    }
                    r->next = q->result_head;
                    q->n_result++;
                    if (q->result_avail_wait) pthread_cond_broadcast(&q->result_avail_c);
                }
            }

            if (q->n_job + q->n_job_unused + q->n_processing < q->job_capacity){
                j->next = q->job_unused;
                q->job_unused = j;
                q->n_job_unused++;
            } else free(j);

            if (t->status == MT_THREAD_BANISHED) {
                q->n_thread--;
                mt_queue_check_wait(q);
                pthread_mutex_unlock(&s->server_m);
                return NULL;
            }
        }
        q->n_thread--;
        mt_queue_check_wait(q);

    }
}

int mt_queue_dispatch_mode(mt_queue *q, uint32_t flag){
    pthread_mutex_lock(&q->s->server_m);
    q->dispatch_mode = flag;
    if (q->job_avail_wait && (q->dispatch_mode == MT_QUEUE_DISPATCH_UNBLOCK || q->dispatch_mode == MT_QUEUE_DISPATCH_UNBLOCK_ONCE))
        pthread_cond_broadcast(&q->job_avail_c);
    pthread_mutex_unlock(&q->s->server_m);
    return 0;
}

int mt_queue_dispatch_end(mt_queue *q){
    pthread_mutex_lock(&q->s->server_m);
    q->flag |= MT_QUEUE_DISPATCH_END;
    pthread_cond_broadcast(&q->wait_c);
    pthread_cond_broadcast(&q->job_avail_c);
    if (q->n_job == 0 && q->n_result == 0 && q->n_processing == 0) {
        q->flag |= MT_QUEUE_RECEIVE_END;
        pthread_cond_broadcast(&q->result_avail_c);
    }
    pthread_mutex_unlock(&q->s->server_m);
    return 0;
}

int mt_queue_dispatch(mt_queue *q, void *(*func)(void *), void *arg, void (*job_cleanup)(void *), void (*result_cleanup)(void *), int non_block){
    mt_job *j;
    pthread_mutex_lock(&q->s->server_m);
    if (q->flag & (MT_QUEUE_DISPATCH_END | MT_QUEUE_SHUTDOWN)) {
        pthread_mutex_unlock(&q->s->server_m);
        return -2;
    }
    if (!non_block){
        while (q->dispatch_mode == MT_QUEUE_DISPATCH_BLOCK && q->job_capacity <= q->n_job + q->n_processing){
            q->job_avail_wait++;
            pthread_cond_wait(&q->job_avail_c, &q->s->server_m);
            q->job_avail_wait--;
            if (q->flag & (MT_QUEUE_DISPATCH_END | MT_QUEUE_SHUTDOWN)) {
                pthread_mutex_unlock(&q->s->server_m);
                return -2;
            }
        }
        if (q->dispatch_mode == MT_QUEUE_DISPATCH_UNBLOCK) non_block = 1;
        else if (q->dispatch_mode == MT_QUEUE_DISPATCH_UNBLOCK_ONCE){
            non_block = 1;
            q->dispatch_mode = MT_QUEUE_DISPATCH_BLOCK;
        }
    }
    if (non_block == 1 && q->job_capacity <= q->n_job + q->n_processing) {
        pthread_mutex_unlock(&q->s->server_m);
        return -1;
    }
    /* for non_block value other than 0 and 1, dispatch any way.*/

    if (q->n_job_unused){
        j = q->job_unused;
        q->job_unused = j->next;
        q->n_job_unused--;
    } else j = malloc(sizeof(*j));

    if (!j){ /* is it ok to tell the caller that the dispatcher is reusable ?*/
        pthread_mutex_unlock(&q->s->server_m);
        usleep(10000);
        return -1;
    }

    j->data = arg;
    j->func = func;
    j->job_cleanup = job_cleanup;
    j->result_cleanup = result_cleanup;
    j->serial = q->curr_serial++;
    j->next = NULL;

    if (q->job_tail){
        q->job_tail->next = j;
        q->job_tail = j;
    } else {
        q->job_head = j;
        q->job_tail = j;
    }
    q->n_job++;
    call_worker(q);

    pthread_mutex_unlock(&q->s->server_m);
    return 0;
}

int mt_queue_receive(mt_queue *q, void **ret, int non_block){
    mt_result *r;
    *ret = NULL;
    pthread_mutex_lock(&q->s->server_m);
    if (q->flag & (MT_QUEUE_RECEIVE_END | MT_QUEUE_SHUTDOWN)) {
        pthread_mutex_unlock(&q->s->server_m);
        return -2;
    }
    if (!non_block) {
        while (!q->result_tail || (q->mode == MT_QUEUE_MODE_SERIAL && q->result_tail->serial != q->next_serial)) {
            q->result_avail_wait++;
            pthread_cond_wait(&q->result_avail_c, &q->s->server_m);
            q->result_avail_wait--;
            if (q->flag & (MT_QUEUE_RECEIVE_END | MT_QUEUE_SHUTDOWN)) {
                pthread_mutex_unlock(&q->s->server_m);
                return -2;
            }
        }
    }
    if (non_block == 1 && (!q->result_tail || (q->mode == MT_QUEUE_MODE_SERIAL && q->result_tail->serial != q->next_serial))) {
        pthread_mutex_unlock(&q->s->server_m);
        return -1;
    }

    r = q->result_tail;
    if (!r->prev){
        q->result_head = NULL;
        q->result_tail = NULL;
    } else{
        q->result_tail = r->prev;
        q->result_tail->next = NULL;
    }
    q->n_result--;
    call_worker(q);

    q->next_serial++;

    *ret = r->data;

    if (q->result_capacity > q->n_result + q->n_result_unused + q->n_processing){
        r->next = q->result_unused;
        q->result_unused = r;
        q->n_result_unused++;
    } else free(r);

    if ((q->flag & MT_QUEUE_DISPATCH_END) && q->n_job == 0 && q->n_result == 0 && q->n_processing == 0) {
        q->flag |= MT_QUEUE_RECEIVE_END;
        pthread_cond_broadcast(&q->result_avail_c);
    }
    mt_queue_check_wait(q);
    pthread_mutex_unlock(&q->s->server_m);
    return 0;
}


mt_server *mt_server_init(int n){
    mt_server *s;
    s = malloc(sizeof(*s));
    if (!s) return NULL;
    s->q_head = NULL;
    s->q_tail = NULL;
    s->n_thread = n;
    s->n_thread_pending = 0;

    s->t = malloc(n * sizeof(s->t[0]));
    if (!s->t) {
        free(s);
        return NULL;
    }

    pthread_mutex_init(&s->server_m, NULL);
    pthread_mutex_lock(&s->server_m);

    for (int i = 0; i < n; ++i){
        mt_thread *t = &s->t[i];
        t->status = MT_THREAD_AVAILABLE;
        t->s = s;
        t->idx = i;
        pthread_cond_init(&t->pending_c, NULL);
        if (0 != pthread_create(&t->tid, NULL, mt_worker, t)){

        }
    }

    pthread_mutex_unlock(&s->server_m);
    return s;
}

int mt_server_destroy(struct mt_server *s){
    pthread_mutex_lock(&s->server_m);
    for (int i = 0; i < s->n_thread; ++i){
        mt_thread *t = &s->t[i];
        t->status = MT_THREAD_BANISHED;
        pthread_cond_signal(&t->pending_c);
    }
    pthread_mutex_unlock(&s->server_m);
    for (int i = 0; i < s->n_thread; ++i){
        mt_thread *t = &s->t[i];
        pthread_join(t->tid, NULL);
    }
    pthread_mutex_lock(&s->server_m);
    for (int i = 0; i < s->n_thread; ++i){
        mt_thread *t = &s->t[i];
        pthread_cond_destroy(&t->pending_c);
    }
    pthread_mutex_destroy(&s->server_m);
    free(s->t);
    free(s);
    return 0;
}

mt_queue *mt_queue_init(mt_server *s, int job_capacity, int result_capacity, int mode){
    mt_queue *q;
    q = malloc(sizeof(*q));
    if (!q) return NULL;
    q->mode = mode;
    if (q->mode == MT_QUEUE_MODE_IGNORED) result_capacity = INT_MAX;
    q->curr_serial = 1;
    q->next_serial = 1;

    q->job_capacity = job_capacity;
    q->n_job = 0;
    q->n_job_unused = 0;
    q->job_head = NULL;
    q->job_tail = NULL;
    q->job_unused = NULL;

    q->result_capacity = result_capacity;
    q->n_result = 0;
    q->n_result_unused = 0;
    q->result_head = NULL;
    q->result_tail = NULL;
    q->result_unused = NULL;

    q->n_processing = 0;
    pthread_cond_init(&q->job_avail_c, NULL);
    q->job_avail_wait = 0;
    pthread_cond_init(&q->result_avail_c, NULL);
    q->result_avail_wait = 0;
    pthread_cond_init(&q->wait_c, NULL);

    q->dispatch_mode = MT_QUEUE_DISPATCH_BLOCK;
    q->n_thread = 0;
    q->ref_count = 0;
    q->flag = 0;
    q->next = NULL;

    q->s = s;

    mt_queue_attach(q, s);
    return q;
}

static inline int mt_queue_check_wait(mt_queue *q){
    if (q->n_thread == 0) pthread_cond_broadcast(&q->wait_c);
    return 0;
};

int mt_queue_wait(mt_queue *q, int f){
    int ret = 0;
    pthread_mutex_lock(&q->s->server_m);
    while (1)
    {
        switch (f) {
            case MT_FINISH:
                if (q->n_job == 0 && q->n_result == 0 && q->n_thread == 0 && (q->flag & MT_QUEUE_DISPATCH_END)) ret =1; /* check when n_result reduced to 0 or dispatch_end is set*/
                if (q->n_thread == 0 && (q->flag & MT_QUEUE_SHUTDOWN)) ret = 2; /* check when n_thread reduced to 0 or shutdown is set*/
                break;
            case MT_FLUSH:
                if (q->n_job == 0 && q->n_thread == 0) ret = 1; /* only need to check when n_thread reduced to 0 */
                if (q->n_thread == 0 && (q->flag & MT_QUEUE_SHUTDOWN)) ret = 2; /* check when n_thread reduced to 0 or shutdown is set*/
                break;
            default: {
                ret = -1;
            }

        }
        if (ret) break;
        pthread_cond_wait(&q->wait_c, &q->s->server_m);
    }
    pthread_mutex_unlock(&q->s->server_m);
    return ret;
}

int mt_queue_set_job_capacity(mt_queue *q, int capacity){
    int overflow;
    pthread_mutex_lock(&q->s->server_m);
    overflow = q->job_capacity - capacity;
    q->job_capacity = capacity;
    if (overflow < 0 && q->job_avail_wait > 0) pthread_cond_broadcast(&q->job_avail_c);

    mt_job *j = q->job_unused;
    while (j){
        if (--overflow < 0) break;
        q->job_unused = j->next;
        q->n_job_unused--;
        free(j);
        j = q->job_unused;
    }

    pthread_mutex_unlock(&q->s->server_m);
    return 0;
}

int mt_queue_set_result_capacity(mt_queue *q, int capacity){
    int overflow;
    pthread_mutex_lock(&q->s->server_m);
    overflow = q->result_capacity - capacity;
    q->result_capacity = capacity;
    if (overflow < 0) call_worker(q);

    mt_result *r = q->result_unused;
    while (r){
        if (--overflow < 0) break;
        q->result_unused = r->next;
        q->n_result_unused--;
        free(r);
        r = q->result_unused;
    }

    pthread_mutex_unlock(&q->s->server_m);
    return 0;
}

int mt_queue_reset(mt_queue *q){ /* currently, the user need to make sure that only workers are visiting mt_queue when calling reset */
    pthread_mutex_lock(&q->s->server_m);
    if (q->job_head) {
        mt_job *j = q->job_head;
        while(j){
            if (j->job_cleanup) j->job_cleanup(j->data);
            j = j->next;
        }

        q->job_tail->next = q->job_unused;
        q->job_unused = q->job_head;
        q->n_job_unused+=q->n_job;
        q->n_job = 0;
        q->job_head = q->job_tail = NULL;
    }

    pthread_mutex_unlock(&q->s->server_m);
    mt_queue_wait(q, MT_FLUSH);
    pthread_mutex_lock(&q->s->server_m);

    if (q->result_head) {
        mt_result *r = q->result_head;
        while(r){
            if (r->result_cleanup) r->result_cleanup(r->data);
            r = r->next;
        }
        q->result_tail->next = q->result_unused;
        q->result_unused = q->result_head;
        q->n_result_unused+=q->n_result;
        q->n_result = 0;
        q->result_head = q->result_tail = NULL;
    }
    q->next_serial = q->curr_serial = 1;
    pthread_mutex_unlock(&q->s->server_m);
    return 0;
}

int mt_queue_shutdown_locked(mt_queue *q){
    q->flag |= MT_QUEUE_SHUTDOWN;
    q->flag |= MT_QUEUE_DISPATCH_END;
    q->flag |= MT_QUEUE_RECEIVE_END;
    pthread_cond_broadcast(&q->job_avail_c);
    pthread_cond_broadcast(&q->result_avail_c);
    pthread_cond_broadcast(&q->wait_c);
    return 0;
}

int mt_queue_shutdown(mt_queue *q){
    pthread_mutex_lock(&q->s->server_m);
    mt_queue_shutdown_locked(q);
    pthread_mutex_unlock(&q->s->server_m);
    return 0;
}

int mt_queue_destroy(mt_queue *q){
    if (mt_queue_wait(q, MT_FINISH) < 0) return -1;
    mt_queue_reset(q); /* since finish, this make sure that dispatcher and receiver as well as worker are not working */
    mt_queue_set_job_capacity(q, 0); /* free job struct */
    mt_queue_set_result_capacity(q, 0);  /* free result struct */

    pthread_cond_destroy(&q->job_avail_c);
    pthread_cond_destroy(&q->result_avail_c);
    pthread_cond_destroy(&q->wait_c);
    mt_queue_detach_locked(q);
    free(q);
    return 0;
}

int mt_queue_auto_destroy(mt_queue *q){
    pthread_mutex_lock(&q->s->server_m);
    q->flag |= MT_QUEUE_AUTO_DESTROY;
    pthread_mutex_unlock(&q->s->server_m);
    if (q->ref_count == 0){
        mt_queue_destroy(q);
    }
    return 0;
}

int mt_queue_ref_incr(mt_queue *q){
    pthread_mutex_lock(&q->s->server_m);
    if (q->flag & MT_QUEUE_SHUTDOWN) {
        pthread_mutex_unlock(&q->s->server_m);
        return -1;
    }
    q->ref_count++;
    pthread_mutex_unlock(&q->s->server_m);
    return 0;
}

int mt_queue_ref_decr(mt_queue *q){
    pthread_mutex_lock(&q->s->server_m);
    q->ref_count--;
    if (q->ref_count < 0) {
        pthread_mutex_unlock(&q->s->server_m);
        return -1;
    }
    if (q->ref_count == 0 && (q->flag & MT_QUEUE_AUTO_DESTROY)){
        pthread_mutex_unlock(&q->s->server_m);
        mt_queue_destroy(q);
    }
    pthread_mutex_unlock(&q->s->server_m);
    return 0;
}

int mt_queue_attach(mt_queue *q, mt_server *s){
    pthread_mutex_lock(&s->server_m);
    q->next = NULL;
    if (!s->q_tail) {
        s->q_head = q;
        s->q_tail = q;
    } else {
        s->q_tail->next = q;
        s->q_tail = q;
    }
    pthread_mutex_unlock(&s->server_m);
    return 0;
}

int mt_queue_detach_locked(mt_queue *q){
    mt_server *s = q->s;
    if (q == s->q_head) {
        s->q_head = q->next;
        if (s->q_tail == q) s->q_tail = NULL;
    }
    else {
        mt_queue *prev = s->q_head;
        while (prev && prev->next != q) prev = prev->next;
        if (!prev) return -1;
        prev->next = q->next;
        if (s->q_tail == q) s->q_tail = prev;
    }
    q->next = NULL;
    return 0;
}

int mt_queue_detach(mt_queue *q){
    int ret;
    pthread_mutex_lock(&q->s->server_m);
    ret = mt_queue_detach_locked(q);
    pthread_mutex_unlock(&q->s->server_m);
    return ret;
}

int mt_server_n_thread(mt_server *s){
    int ret;
    pthread_mutex_lock(&s->server_m);
    ret = s->n_thread;
    pthread_mutex_unlock(&s->server_m);
    return ret;
}












