/* The MIT License (MIT)

   Copyright (c) 2023 Anrui Liu <liuar6@gmail.com>

   Permission is hereby granted, free of charge, to any person obtaining
   a copy of this software and associated documentation files (the
   “Software”), to deal in the Software without restriction, including
   without limitation the rights to use, copy, modify, merge, publish,
   distribute, sublicense, and/or sell copies of the Software, and to
   permit persons to whom the Software is furnished to do so, subject to
   the following conditions:

   The above copyright notice and this permission notice shall be
   included in all copies or substantial portions of the Software.

   THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND,
   EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
   MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
   NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
   BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
   ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
   CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
   SOFTWARE.
 */

#include <pthread.h>
#include <stdlib.h>

struct mt_buffer_item{
    struct mt_buffer_item *next;
    void *data;
};

struct mt_buffer{
    struct mt_buffer_item *item;
    struct mt_buffer_item *unused_item;
    pthread_mutex_t buffer_m;
    pthread_cond_t item_avail_c;
    int item_avail_wait;

};
struct mt_buffer *mt_buffer_init(){
    struct mt_buffer *b = malloc(sizeof(struct mt_buffer));
    if (!b) return NULL;
    b->item = NULL;
    b->unused_item = NULL;
    pthread_mutex_init(&b->buffer_m, NULL);
    pthread_cond_init(&b->item_avail_c, NULL);
    b->item_avail_wait = 0;
    return b;
}

int mt_buffer_destroy(struct mt_buffer *b, void(*func)(void *)){
    pthread_mutex_lock(&b->buffer_m);
    struct mt_buffer_item *item, *next;
    for (item = b->item; item; ){
        next = item->next;
        if (func) func(item->data);
        free(item);
        item = next;
    }
    for (item = b->unused_item; item; ){
        next = item->next;
        free(item);
        item = next;
    }
    if (b->item) return -1;
    if (b->item_avail_wait) return -1;
    pthread_cond_destroy(&b->item_avail_c);
    pthread_mutex_destroy(&b->buffer_m);
    free(b);
    return 0;
}
int mt_buffer_put(struct mt_buffer *b, void* data){
    pthread_mutex_lock(&b->buffer_m);
    struct mt_buffer_item *item;
    if (b->unused_item){
        item = b->unused_item;
        b->unused_item = item->next;
    } else item = malloc(sizeof(struct mt_buffer_item));
    if (!item) return -1;
    item->next = b->item;
    item->data = data;
    b->item = item;
    if (b->item_avail_wait) pthread_cond_signal(&b->item_avail_c);
    pthread_mutex_unlock(&b->buffer_m);
    return 0;
};
void *mt_buffer_get(struct mt_buffer *b){
    pthread_mutex_lock(&b->buffer_m);
    while (!b->item){
        b->item_avail_wait++;
        pthread_cond_wait(&b->item_avail_c, &b->buffer_m);
        b->item_avail_wait--;
    }
    struct mt_buffer_item *item = b->item;
    b->item = item->next;
    void *ret = item->data;
    item->next = b->unused_item;
    b->unused_item = item;
    pthread_mutex_unlock(&b->buffer_m);
    return ret;
};

